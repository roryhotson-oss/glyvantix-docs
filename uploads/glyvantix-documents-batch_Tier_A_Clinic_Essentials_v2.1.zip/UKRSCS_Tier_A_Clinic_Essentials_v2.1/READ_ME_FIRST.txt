Tier A Clinic Essentials
============================================================
Publisher : UK-RSCS - UK Regulatory & Scientific Compliance Solutions
Tagline   : Peptide Practice, Papered Properly.

Intended for: Single-site private weight-management clinic, 1-3 prescribers, England
Templates in this bundle: 45
Formats: PDF (reference) and DOCX (editable Word)

An independent commercial publisher. Not a regulator, standards body or public authority.
Not affiliated with, endorsed, accredited or approved by the MHRA, CQC, NHS or any government agency. Confers no regulatory approval.

BEFORE YOU USE ANYTHING IN THIS BUNDLE
--------------------------------------
1. Read 00_MASTER_INDEX_and_Implementation_Guide (PDF folder).
2. Read 00b_Methodology_Provenance_and_Claims_Statement - this sets out
   how the suite was produced and what has NOT been independently reviewed.
3. Read 00c_Tier_Structure_and_Coverage_Matrix to see what this tier
   excludes and when you need to upgrade.
4. Work through the localisation checklist in the Master Index. Every
   [PLACEHOLDER] must be completed before use.
5. Obtain your own legal, pharmacy and clinical governance sign-off.

These are TEMPLATES. They are not valid until adopted, localised and
approved by your organisation. They confer no regulatory approval.

Codes are permanent. PCO-001 is the same document in every tier and
every version, so upgrades never conflict with what you already hold.
